<?php 
	use yii\helpers\Html;
	use yii\widgets\DetailView;

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Yii 2</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script> -->
</head>
<body>

<div class="container mt-3">
  <h2>Basic Table</h2>
  <p>Posts Details</p>            
  <table class="table">
    <thead>
      <tr>
        <th>Serial No.</th>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Email</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
    <?php if(count($posts)>0):?>	
      	<?php foreach($posts as $post):?>
      	<tr>
        	<td>1</td>
        	<td><?php echo $post->title; ?></td>
        	<td><?php echo $post->description;?></td>
        	<td><?php echo $post->category;?></td>
        	<td>
        		<?= Html::a('View', ['view', 'id' => $post->id]) ?>
                <?= Html::a('Edit', ['edit', 'id' => $post->id]) ?>
                <?= Html::a('Delete', ['delete', 'id' => $post->id], ['data-method' => 'post', 'data-confirm' => 'Are you sure you want to delete this item?']) ?>
        	</td>
      	</tr>
      	<?php endforeach; ?>
     
    <?php else:?>
      	<tr>
      		<td> No Record Found... </td>
      	</tr>
    <?php endif; ?>	
      
    </tbody>
  </table>
</div>

</body>
</html>
